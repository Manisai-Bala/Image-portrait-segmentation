# portrait_segmentation
Portrait segmentation refers to the process of segmenting a person in an image from its background. Here we use the concept of semantic segmentation to predict the label of every pixel (dense prediction) in an image. 




This technique  is widely used in computer vision applications like background replacement and background blurring on mobile devices.



Here we limit ourselves to binary classes (person or background) and use only plain portrait-selfie images for matting.




# dataset_link
https://www.kaggle.com/laurentmih/aisegmentcom-matting-human-datasets



# Linkedin_post-link--Deployment video
https://www.linkedin.com/posts/mohan-reddy-pallavula-440a26151_portraitabrsegmentation-segnet-aisegment-activity-6705821514987655168-Fl3G


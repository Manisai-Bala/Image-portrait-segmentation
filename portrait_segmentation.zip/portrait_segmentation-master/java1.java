import java.util.*;
class java1
{
	public static void main(String[] args)
	{
			int[] arr=new int[10];
			for(int i=0;i<7;i++)
			{
				arr[i]=sc.nextInt();
			}
			System.out.println(arr[0]);
		
	}
}